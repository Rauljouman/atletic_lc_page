import Head from "next/head";
import PavilionSection from "@/components/PavilionSection";
import GroupSection from "@/components/GroupSection";
import ContactForm from "@/components/ContactForm";

export default function Home() {
  return (
    <>
      <Head>
        <title>Atletic Les Corts Futsal – Club de Fútbol Sala en Barcelona</title>
        <meta
          name="description"
          content="Atletic Les Corts Futsal es un club de fútbol sala de Barcelona, ubicado en el barrio de Les Corts. Contamos con equipos en todas las categorías formativas y sénior."
        />
        <meta name="robots" content="index, follow" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <meta property="og:title" content="Atletic Les Corts Futsal – Fútbol Sala en Les Corts, Barcelona" />
        <meta
          property="og:description"
          content="Club de fútbol sala con sede en Les Corts, Barcelona. Equipos de base y sénior en todas las categorías. ¡Forma parte de nuestra comunidad deportiva!"
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://atletic-les-corts.com/" /> 
        <meta property="og:image" content="@/assets/logo.png" />
        
        <link rel="canonical" href="https://atletic-les-corts.com/" />
      </Head>

      <div className="sectionWrapper">
        <GroupSection />
        <PavilionSection />
        <ContactForm />
      </div>
    </>
  );
}
